<?php
/**
 * Created by PhpStorm.
 * User: liufangting
 * Date: 2017/8/31
 * Time: 11:05
 */
require_once './SessionFile.php';
SessionFile::start();
$_SESSION['name']='daopangzi';
session_commit();


